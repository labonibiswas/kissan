class Product:
    def __init__(self, name, price):
        self.name = name
        self.price = price

class ShoppingCart:
    def __init__(self):
        self.items = []

    def add_product(self, product, quantity=1):
        self.items.append({'product': product, 'quantity': quantity})

    def total_price(self):
        total = 0
        for item in self.items:
            total += item['product'].price * item['quantity']
        return total

# Example usage:
product1 = Product("Laptop", 1000)
product2 = Product("Phone", 500)

cart = ShoppingCart()
cart.add_product(product1)
cart.add_product(product2, 2)

print("Total price in cart:", cart.total_price())
