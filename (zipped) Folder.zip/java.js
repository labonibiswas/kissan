let list = document.querySelector('.slider .list');
let items = document.querySelector('.slider .list .item');
let dots = document.querySelector('.slider .dots li');
let prev = document.getElementById('prev');
let next = document.getElementById('next');

let active = 0;
let lenghtItems = items.length -1;

next.onclick = function(){
    if(active + 1 > lenghtItems){
        active = 0;
    }else{
        active = active + 1;
    }
    reloadslider();
}
prev.onclick = function(){
    if(active - 1 < 0){
        active = lenghtItems;
    }else{
        active = active - 1;
    }
}
let refreshslider = setInterval(() => (next.click()),3000)
function reloadslider(){
    let checkleft = items[active].offsetleft;
    list.style.left = -checkleft + 'px';

    let lastActiveDot = document.querySelector('.slider .dot li.active');
    lastActiveDot.classList.remove('active');
    dots[active].classList.add('active');
}
dots.forEach((li,key) =>{
    li.addEventlistener('click',function){
        active = key;
        reloadslider();
    }
})